

import './App.css'
import Leads from './Leads'

function App() {

return (
  <>
 
  <h1>Hello Priyanshu Garg is Here </h1>
  <Leads/> 
  </>
  )
}

export default App
